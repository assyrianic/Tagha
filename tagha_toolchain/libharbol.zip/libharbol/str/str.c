#include "str.h"

#ifdef OS_WINDOWS
#	define HARBOL_LIB
#endif

#include <ctype.h>

static NO_NULL bool __harbol_resize_string(struct HarbolString *const restrict string, const size_t new_size)
{
	const size_t old_size = string->len;
	// check if we're reducing or increasing memory.
	// as realloc is exponentially faster when we're reducing memory.
	const bool increasing_mem = (old_size <= new_size);
	if( increasing_mem ) {
		char *restrict newstr = harbol_alloc(new_size + 1, sizeof *newstr);
		if( newstr==NULL )
			return false;
		else {
			string->len = new_size;
			if( string->cstr != NIL ) {
				char *restrict buf = ( char* )string->cstr;
				memcpy(newstr, buf, old_size);
				harbol_free(buf), string->cstr = NIL;
			}
			string->cstr = ( uintptr_t )newstr;
			return true;
		}
	} else {
		char *restrict buf = ( char* )string->cstr;
		buf = harbol_realloc(buf, new_size * sizeof *buf + 1);
		if( buf==NULL )
			return false;
		else {
			string->cstr = ( uintptr_t )buf;
			string->len = new_size;
			buf[string->len] = '\0';
			return true;
		}
	}
}


HARBOL_EXPORT struct HarbolString *harbol_string_new(const char cstr[restrict])
{
	struct HarbolString *restrict string = harbol_alloc(1, sizeof *string);
	if( string != NULL )
		*string = harbol_string_create(cstr);
	return string;
}

HARBOL_EXPORT struct HarbolString harbol_string_create(const char cstr[restrict])
{
	struct HarbolString string = {0};
	harbol_string_copy_cstr(&string, cstr);
	return string;
}

HARBOL_EXPORT bool harbol_string_clear(struct HarbolString *const string)
{
	if( string->cstr != NIL ) {
		char *restrict buf = ( char* )string->cstr;
		harbol_free(buf);
		string->cstr = NIL;
	}
	*string = (struct HarbolString){0};
	return true;
}

HARBOL_EXPORT bool harbol_string_free(struct HarbolString **const stringref)
{
	if( *stringref==NULL )
		return false;
	else {
		harbol_string_clear(*stringref);
		harbol_free(*stringref), *stringref=NULL;
		return true;
	}
}

HARBOL_EXPORT bool harbol_string_add_char(struct HarbolString *const string, const char c)
{
	const bool resize_res = __harbol_resize_string(string, string->len + 1);
	if( !resize_res )
		return false;
	else {
		char *restrict buf = ( char* )string->cstr;
		buf[string->len-1] = c;
		return true;
	}
}

HARBOL_EXPORT bool harbol_string_add_str(struct HarbolString *const stringA, const struct HarbolString *const stringB)
{
	if( stringB->cstr==NIL )
		return false;
	else {
		const bool resize_res = __harbol_resize_string(stringA, stringA->len + stringB->len);
		if( !resize_res )
			return false;
		else {
			char *restrict bufA = ( char* )stringA->cstr;
			const char *restrict bufB = ( const char* )stringB->cstr;
			strncat(bufA, bufB, stringB->len);
			return true;
		}
	}
}

HARBOL_EXPORT bool harbol_string_add_cstr(struct HarbolString *const restrict string, const char cstr[restrict])
{
	if( cstr==NULL )
		return false;
	else {
		const size_t cstr_len = strlen(cstr);
		const bool resize_res = __harbol_resize_string(string, string->len + cstr_len);
		if( !resize_res )
			return false;
		else {
			char *restrict buf = ( char* )string->cstr;
			strncat(buf, cstr, cstr_len);
			return true;
		}
	}
}

HARBOL_EXPORT inline char *harbol_string_cstr(const struct HarbolString *const string)
{
	return ( char* )string->cstr;
}

HARBOL_EXPORT inline size_t harbol_string_len(const struct HarbolString *const string)
{
	return string->len;
}

HARBOL_EXPORT bool harbol_string_copy_str(struct HarbolString *const stringA, const struct HarbolString *const stringB)
{
	if( stringB->cstr==NIL )
		return false;
	else if( stringA==stringB )
		return true;
	else {
		const bool resize_res = __harbol_resize_string(stringA, stringB->len);
		if( !resize_res )
			return false;
		else {
			char *restrict bufA = ( char* )stringA->cstr;
			const char *restrict bufB = ( char* )stringB->cstr;
			strncpy(bufA, bufB, stringB->len);
			return true;
		}
	}
}

HARBOL_EXPORT bool harbol_string_copy_cstr(struct HarbolString *const restrict string, const char cstr[restrict])
{
	if( cstr==NULL )
		return false;
	else {
		const size_t cstr_len = strlen(cstr);
		const bool resize_res = __harbol_resize_string(string, cstr_len);
		if( !resize_res )
			return false;
		else {
			char *restrict buf = ( char* )string->cstr;
			strncpy(buf, cstr, string->len);
			return true;
		}
	}
}

HARBOL_EXPORT int32_t harbol_string_format(struct HarbolString *const restrict string, const char fmt[restrict static 1], ...)
{
	va_list ap, st;
	va_start(ap, fmt);
	va_copy(st, ap);
	/*
		'*snprintf' family returns the size of how large the writing
		would be if the buffer was large enough.
	*/
	char c = 0;
	const int32_t size = vsnprintf(&c, 1, fmt, ap);
	va_end(ap);
	
	const bool resize_res = __harbol_resize_string(string, size);
	if( !resize_res ) {
		va_end(st);
		return -1;
	} else {
		/* vsnprintf always checks n-1 so gotta increase len a bit to accomodate. */
		char *restrict buf = ( char* )string->cstr;
		const int32_t result = vsnprintf(buf, string->len+1, fmt, st);
		va_end(st);
		return result;
	}
}

HARBOL_EXPORT int32_t harbol_string_add_format(struct HarbolString *const restrict str, const char fmt[restrict static 1], ...)
{
	va_list ap, st;
	va_start(ap, fmt);
	va_copy(st, ap);
	
	char c = 0;
	const int32_t size = vsnprintf(&c, 1, fmt, ap);
	va_end(ap);
	
	const size_t old_size = str->len;
	const bool resize_res = __harbol_resize_string(str, size + old_size);
	if( !resize_res ) {
		va_end(st);
		return -1;
	} else {
		char *restrict buf = ( char* )str->cstr;
		const int32_t result = vsnprintf(&buf[old_size], str->len-old_size+1, fmt, st);
		va_end(st);
		return result;
	}
}

HARBOL_EXPORT int32_t harbol_string_scan(struct HarbolString *const restrict string, const char fmt[restrict static 1], ...)
{
	va_list args;
	va_start(args, fmt);
	char *restrict buf = ( char* )string->cstr;
	const int32_t result = vsscanf(buf, fmt, args);
	va_end(args);
	return result;
}

HARBOL_EXPORT int32_t harbol_string_cmpcstr(const struct HarbolString *const restrict string, const char cstr[restrict])
{
	if( cstr==NULL || string->cstr==NIL )
		return -1;
	else {
		const size_t cstr_len = strlen(cstr);
		return strncmp(cstr, string->cstr, (string->len > cstr_len) ? string->len : cstr_len);
	}
}

HARBOL_EXPORT int32_t harbol_string_cmpstr(const struct HarbolString *const restrict stringA, const struct HarbolString *const restrict stringB)
{
	return( stringA->cstr==NIL || stringB->cstr==NIL ) ? -1 : strncmp(( const char* )stringA->cstr, ( const char* )stringB->cstr, stringA->len > stringB->len ? stringA->len : stringB->len);
}

HARBOL_EXPORT bool harbol_string_is_empty(const struct HarbolString *const string)
{
	return( string->cstr==NIL || string->len==0 || (( const char* )string->cstr)[0]==0 );
}

HARBOL_EXPORT bool harbol_string_read_file(struct HarbolString *const restrict string, FILE *const restrict file)
{
	const ssize_t filesize = get_file_size(file);
	if( filesize<=0 )
		return false;
	else {
		const bool resize_res = __harbol_resize_string(string, filesize);
		if( !resize_res )
			return false;
		else {
			char *restrict buf = ( char* )string->cstr;
			string->len = fread(buf, sizeof *buf, filesize, file);
			return string->len == ( size_t )filesize;
		}
	}
}

HARBOL_EXPORT bool harbol_string_replace(struct HarbolString *const restrict string, const char to_replace, const char with)
{
	if( string->cstr==NIL || to_replace==0 || with==0 )
		return false;
	else {
		for( char *restrict i = ( char* )string->cstr; *i != 0; i++ )
			if( *i==to_replace )
				*i = with;
		return true;
	}
}

HARBOL_EXPORT size_t harbol_string_count(const struct HarbolString *const restrict string, const char occurrence)
{
	if( string->cstr==NIL )
		return 0;
	else {
		size_t counts = 0;
		for( const char *restrict i = ( const char* )string->cstr; *i != 0; i++ )
			if( *i==occurrence )
				++counts;
		return counts;
	}
}

HARBOL_EXPORT bool harbol_string_upper(struct HarbolString *const restrict string)
{
	if( string->cstr==NIL )
		return false;
	else {
		for( char *restrict i = ( char* )string->cstr; *i != 0; i++ )
			if( islower(*i) )
				*i=toupper(*i);
		return true;
	}
}

HARBOL_EXPORT bool harbol_string_lower(struct HarbolString *const restrict string)
{
	if( string->cstr==NIL )
		return false;
	else {
		for( char *restrict i = ( char* )string->cstr; *i != 0; i++ )
			if( isupper(*i) )
				*i=tolower(*i);
		return true;
	}
}

HARBOL_EXPORT bool harbol_string_reverse(struct HarbolString *const restrict string)
{
	if( string->cstr==NIL )
		return false;
	else {
		char *restrict buf = ( char* )string->cstr;
		const size_t len = string->len / 2;
		for( uindex_t i=0, n=string->len-1; i<len; i++, n-- ) {
			if( buf[n]==buf[i] )
				continue;
			else {
				buf[n] ^= buf[i];
				buf[i] ^= buf[n];
				buf[n] ^= buf[i];
			}
		}
		return true;
	}
}
