#ifndef HARBOL_GRAPHPOOL_INCLUDED
#	define HARBOL_GRAPHPOOL_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "../../harbol_common_defines.h"
#include "../../harbol_common_includes.h"
#include "../cache/cache.h"

// Edge
struct HarbolPage;
struct HarbolBlock {
	size_t size;
	struct HarbolBlock *next;
	struct HarbolPage  *owner, *link;
};

// Vertices
struct HarbolPage {
	struct HarbolCache stack; // arena of blocks.
	struct HarbolBlock *block;
};

struct HarbolGraphPool {
	struct HarbolPage *pages;
	size_t len;
};

enum {
	GRAPH_POOL_PAGE_SIZE = 2048
};


HARBOL_EXPORT struct HarbolGraphPool harbol_graphpool_create(size_t size);
HARBOL_EXPORT NO_NULL struct HarbolGraphPool harbol_graphpool_from_buffer(void *buf, size_t pages, size_t page_size);
HARBOL_EXPORT NO_NULL bool harbol_graphpool_clear(struct HarbolGraphPool *gpool);

HARBOL_EXPORT NO_NULL void *harbol_graphpool_alloc(struct HarbolGraphPool *gpool, size_t bytes);
HARBOL_EXPORT NEVER_NULL(1) void *harbol_graphpool_realloc(struct HarbolGraphPool *gpool, void *ptr, size_t bytes);
HARBOL_EXPORT NEVER_NULL(1) bool harbol_graphpool_free(struct HarbolGraphPool *gpool, void *ptr);
HARBOL_EXPORT NO_NULL bool harbol_graphpool_cleanup(struct HarbolGraphPool *gpool, void **ptrref);

HARBOL_EXPORT NO_NULL size_t harbol_graphpool_mem_remaining(const struct HarbolGraphPool *gpool);
/********************************************************************/

#ifdef __cplusplus
}
#endif

#endif /* HARBOL_GRAPHPOOL_INCLUDED */
