#include "graphpool.h"

#ifdef OS_WINDOWS
#	define HARBOL_LIB
#endif


HARBOL_EXPORT struct HarbolGraphPool harbol_graphpool_create(const size_t size)
{
	struct HarbolGraphPool gpool = { 0 };
	if( size==0 )
		return gpool;
	else {
		size_t page_count = size / GRAPH_POOL_PAGE_SIZE;
		if( page_count==0 )
			page_count = 1;
		
		struct HarbolPage *const page_buf = calloc(page_count, sizeof *page_buf);
		if( page_buf==NULL )
			return gpool;
		else {
			gpool.pages = page_buf;
			gpool.len = page_count;
			for( size_t i=0; i<page_count; i++ ) {
				gpool.pages[i].stack = harbol_cache_create(GRAPH_POOL_PAGE_SIZE);
			}
			return gpool;
		}
	}
}

HARBOL_EXPORT struct HarbolGraphPool harbol_graphpool_from_buffer(void *const restrict buf, const size_t size)
{
	struct HarbolGraphPool gpool = { 0 };
	if( size==0 || size<=sizeof(struct HarbolMemNode) )
		return gpool;
	else {
		gpool.stack = harbol_cache_from_buffer(buf, size);
		return gpool;
	}
}

HARBOL_EXPORT bool harbol_graphpool_clear(struct HarbolGraphPool *const gpool)
{
	bool result = harbol_cache_clear(&gpool->stack);
	*gpool = (struct HarbolGraphPool){ 0 };
	return result;
}

HARBOL_EXPORT void *harbol_graphpool_alloc(struct HarbolGraphPool *const gpool, const size_t size)
{
	
}

HARBOL_EXPORT void *harbol_graphpool_realloc(struct HarbolGraphPool *const restrict gpool, void *const ptr, const size_t size)
{
	
}

HARBOL_EXPORT bool harbol_graphpool_free(struct HarbolGraphPool *const restrict gpool, void *const ptr)
{
	
}

HARBOL_EXPORT bool harbol_graphpool_cleanup(struct HarbolGraphPool *const restrict gpool, void **const restrict ptrref)
{
	if( *ptrref==NULL )
		return false;
	else {
		const bool free_result = harbol_graphpool_free(gpool, *ptrref);
		*ptrref = NULL;
		return free_result;
	}
}

HARBOL_EXPORT size_t harbol_graphpool_mem_remaining(const struct HarbolGraphPool *gpool)
{
	
}