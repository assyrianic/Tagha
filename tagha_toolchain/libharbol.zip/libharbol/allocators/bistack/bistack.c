#include "bistack.h"

#ifdef OS_WINDOWS
#	define HARBOL_LIB
#endif


HARBOL_EXPORT struct HarbolBiStack harbol_bistack_create(const size_t len)
{
	struct HarbolBiStack bistack = EMPTY_HARBOL_BISTACK;
	if( len==0 )
		return bistack;
	else {
		uint8_t *const restrict buf = malloc(len * sizeof *buf);
		if( buf==NULL )
			return bistack;
		else {
			bistack.size = len;
			bistack.mem = ( uintptr_t )buf;
			bistack.front = bistack.mem;
			bistack.back = bistack.mem + len;
			return bistack;
		}
	}
}

HARBOL_EXPORT struct HarbolBiStack harbol_bistack_create_from_buffer(void *const restrict buf, const size_t len)
{
	struct HarbolBiStack bistack = EMPTY_HARBOL_BISTACK;
	if( len==0 )
		return bistack;
	
	bistack.size = len;
	bistack.mem = bistack.front = ( uintptr_t )buf;
	bistack.back = bistack.mem + len;
	return bistack;
}

HARBOL_EXPORT void harbol_bistack_clear(struct HarbolBiStack *const restrict bistack)
{
	if( bistack->mem==0 )
		return;
	
	void *const restrict buf = ( void* )bistack->mem;
	free(buf);
	*bistack = (struct HarbolBiStack)EMPTY_HARBOL_BISTACK;
}

HARBOL_EXPORT void *harbol_bistack_alloc_front(struct HarbolBiStack *const restrict bistack, const size_t size)
{
	if( bistack->mem==0 )
		return NULL;
	else {
		const size_t aligned_size = harbol_align_size(size, sizeof(uintptr_t));
		// front end arena is too high!
		if( bistack->front + aligned_size >= bistack->back )
			return NULL;
		else {
			void *const restrict ptr = ( void* )bistack->front;
			bistack->front += aligned_size;
			return ptr;
		}
	}
}

HARBOL_EXPORT void *harbol_bistack_alloc_back(struct HarbolBiStack *const restrict bistack, const size_t size)
{
	if( bistack->mem==0 )
		return NULL;
	else {
		const size_t aligned_size = harbol_align_size(size, sizeof(uintptr_t));
		// back end arena is too low
		if( bistack->back - aligned_size <= bistack->front )
			return NULL;
		else {
			bistack->back -= aligned_size;
			void *const restrict ptr = ( void* )bistack->back;
			return ptr;
		}
	}
}

HARBOL_EXPORT void harbol_bistack_reset_front(struct HarbolBiStack *const bistack)
{
	if( bistack->mem==0 )
		return;
	
	bistack->front = bistack->mem;
}

HARBOL_EXPORT void harbol_bistack_reset_back(struct HarbolBiStack *const bistack)
{
	if( bistack->mem==0 )
		return;
	
	bistack->back = bistack->mem + bistack->size;
}

HARBOL_EXPORT void harbol_bistack_reset_all(struct HarbolBiStack *const bistack)
{
	harbol_bistack_reset_back(bistack);
	harbol_bistack_reset_front(bistack);
}

HARBOL_EXPORT ssize_t harbol_bistack_get_margins(const struct HarbolBiStack bistack)
{
	return ( ssize_t )bistack.back - ( ssize_t )bistack.front;
}
