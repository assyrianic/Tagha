#ifndef HARBOL_BISTACK_INCLUDED
#	define HARBOL_BISTACK_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

#include "../../harbol_common_defines.h"
#include "../../harbol_common_includes.h"


// Double-Ended Stack aka Deque
struct HarbolBiStack {
    uintptr_t mem, front, back;
    size_t size;
};

#define EMPTY_HARBOL_BISTACK    { 0,0,0,0 }


HARBOL_EXPORT NO_NULL struct HarbolBiStack harbol_bistack_create(size_t len);
HARBOL_EXPORT NO_NULL struct HarbolBiStack harbol_bistack_create_from_buffer(void *buf, size_t len);
HARBOL_EXPORT NO_NULL void harbol_bistack_clear(struct HarbolBiStack *bistack);

HARBOL_EXPORT NO_NULL void *harbol_bistack_alloc_front(struct HarbolBiStack *bistack, size_t size);
HARBOL_EXPORT NO_NULL void *harbol_bistack_alloc_back(struct HarbolBiStack *bistack, size_t size);

HARBOL_EXPORT NO_NULL void harbol_bistack_reset_front(struct HarbolBiStack *bistack);
HARBOL_EXPORT NO_NULL void harbol_bistack_reset_back(struct HarbolBiStack *bistack);
HARBOL_EXPORT NO_NULL void harbol_bistack_reset_all(struct HarbolBiStack *bistack);

HARBOL_EXPORT NO_NULL ssize_t harbol_bistack_get_margins(struct HarbolBiStack bistack);
/********************************************************************/


#ifdef __cplusplus
}
#endif

#endif /* HARBOL_BISTACK_INCLUDED */
