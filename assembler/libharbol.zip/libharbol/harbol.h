#ifndef HARBOL_INCLUDED
#	define HARBOL_INCLUDED
#	define HARBOL_VERSION_MAJOR    2
#	define HARBOL_VERSION_MINOR    2
#	define HARBOL_VERSION_PATCH    4
#	define HARBOL_VERSION_PHASE    'B'
#	define STR_HELPER(x)    #x
#	define STR(x)    STR_HELPER(x)
#	define HARBOL_VERSION_STRING \
			STR(HARBOL_VERSION_MAJOR) "." STR(HARBOL_VERSION_MINOR) "." STR(HARBOL_VERSION_PATCH) " " STR(HARBOL_VERSION_PHASE)

#ifdef __cplusplus
extern "C" {
#endif

#include "harbol_common_defines.h"

#ifndef C99
#	error "Harbol requires a C99 compliant compiler with at least stdbool.h, inttypes.h, compound literals, and designated initializers."
#endif

/************* C++ Style Automated String *************/
#include "stringobj/stringobj.h"
/******************************************************/

/************* Dynamic Array *************/
#include "vector/vector.h"
/*****************************************/

/************* Byte Buffer *************/
#include "bytebuffer/bytebuffer.h"
/**************************************/

/************* String-based Hash Table *************/
#include "map/map.h"
/***************************************************/

/************* Linked Hashmap (preserves insertion order) *************/
#include "linkmap/linkmap.h"
/**********************************************************************/

#ifdef __cplusplus
}
#endif

#endif /* HARBOL_INCLUDED */
